document.getElementById('loginForm').addEventListener('submit', function(event) {
    // Prevent form submission initially
    event.preventDefault();

    // Email and password validation
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    if (!email || !password) {
        alert("Please fill in both fields.");
        return; // Stop the script here
    }


    // Simple email validation using regex
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    if (!emailRegex.test(email)) {
        alert("Please enter a valid email address.");
        return; // Stop the script here
    }

    // Allow any email and password combination to "log in"
    alert("Login successfully!"); // Show success message
    // Redirect to the home page
    window.location.href = 'index.html'; // Redirect to home page
});
