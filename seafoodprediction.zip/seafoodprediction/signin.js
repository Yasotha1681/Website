document.getElementById('signinForm').addEventListener('submit', function(event) {
    // Prevent form submission initially
    event.preventDefault();

    // Get form data
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    
    // Validation for empty fields
    if (!name || !email || !password || !confirmPassword) {
        alert("Please fill in all the fields.");
        return; // Stop the script here
    } 
    
    // Check if passwords match
    if (password !== confirmPassword) {
        alert("Passwords do not match.");
        return; // Stop the script here
    }

    // Simple email validation using regex
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    if (!emailRegex.test(email)) {
        alert("Please enter a valid email address.");
        return; // Stop the script here
    }

    // Simulate successful sign-up (In a real case, you would send the data to the server here)
    alert("Sign-up successful! Redirecting to login page...");

    // After successful sign-up, redirect to login page
    window.location.href = 'login.html'; // Redirect to login page
});
